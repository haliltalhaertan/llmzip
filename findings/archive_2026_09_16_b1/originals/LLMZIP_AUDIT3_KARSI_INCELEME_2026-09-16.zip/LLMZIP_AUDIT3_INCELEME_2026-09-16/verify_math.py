#!/usr/bin/env python3
"""Analytical counterchecks, NOT a reproduction of audit3 or an LLMZIP benchmark.
All inputs here are explicitly synthetic. No archive or test labels are used.
"""
from pathlib import Path
import json, math, platform, time
import numpy as np
from scipy.linalg import hadamard

ROOT = Path(__file__).resolve().parent
started = time.perf_counter()
checks = {}
# 1. A fixed trace is not a bound on each diagonal or a chosen subset.
n, k, m = 500, 96, 50
U = np.eye(n, k)
rho = np.einsum('ij,ij->i', U, U)
assert np.array_equal(U.T @ U, np.eye(k))
assert np.all(rho[:m] == 1) and rho.sum() == k
checks['selected_subset'] = {
    'N': n, 'rank': k, 'priority_subset_size': m,
    'uniform_row_mean': float(rho.mean()),
    'priority_subset_mean': float(rho[:m].mean()),
    'other_rows_mean': float(rho[m:].mean()),
    'trace': float(rho.sum()),
    'claim': 'Same rank96 can fully retain a chosen 50-axis subset; others pay the cost.',
    'limitation': 'Unconstrained synthetic projection. Does not identify useful real query axes.'
}
# Haar orthobasis: every realization has row-average k/n, but individual rows vary.
rng = np.random.default_rng(20260916)
traces, target_rows = [], []
for _ in range(40):
    Q, _ = np.linalg.qr(rng.normal(size=(n, k)), mode='reduced')
    r = np.einsum('ij,ij->i', Q, Q)
    traces.append(float(r.sum())); target_rows.append(float(r[0]))
checks['haar_40_draws'] = {
    'target_e0_sample_mean': float(np.mean(target_rows)),
    'target_e0_sample_min': float(np.min(target_rows)),
    'target_e0_sample_max': float(np.max(target_rows)),
    'theoretical_expectation': k/n,
    'max_abs_trace_error': float(np.max(np.abs(np.array(traces)-k)))
}
# 2. Equal preservation at EVERY singleton need not imply equal retrieval quality.
# Z = I_512. All singular values are 1, so both chosen orthobases are valid
# best rank96 approximations. This degenerate synthetic case suffices to
# disprove a universal no-better-directions claim; not a natural-language test.
n, k = 512, 96
H = hadamard(n).astype(np.float64)
bad_columns = list(range(1, k+1))
identity_columns = [1 << j for j in range(9)]
good_columns = identity_columns + [j for j in range(1, n) if j not in identity_columns][:k-9]
retrieval = {}
for name, cols in [('colliding', bad_columns), ('distinct', good_columns)]:
    V = H[:, cols] / math.sqrt(n)
    assert V.shape == (n, k)
    ortho_error = float(np.max(np.abs(V.T @ V - np.eye(k))))
    assert ortho_error < 1e-12
    leverage = np.einsum('ij,ij->i', V, V)
    assert np.allclose(leverage, k/n, rtol=0, atol=1e-14)
    # Correct row-norm and mean pipeline; sign patterns are unchanged.
    Y = V / np.linalg.norm(V, axis=1, keepdims=True)
    C = Y - Y.mean(axis=0)
    codes = C >= 0
    packed = np.packbits(codes, axis=1, bitorder='little')
    unique, inverse, counts = np.unique(packed, axis=0, return_inverse=True, return_counts=True)
    tie_sizes = counts[inverse]
    # Query e_i uses row i of V, hence the same code. Gold is only doc i.
    expected_hit1 = float(np.mean(1.0/tie_sizes))
    expected_fr3 = float(np.mean(np.minimum(3,tie_sizes)/tie_sizes))
    assert np.max(np.abs(C - Y)) < 1e-14
    retrieval[name] = {
        'columns': cols, 'orthogonality_max_error': ortho_error,
        'all_singleton_preservation': float(leverage[0]),
        'max_abs_preservation_deviation': float(np.max(np.abs(leverage-k/n))),
        'trace': float(leverage.sum()),
        'rank': k, 'documents_and_self_queries': n,
        'unique_96bit_codes': int(len(unique)),
        'code_collision_group_sizes': sorted(np.unique(tie_sizes).astype(int).tolist()),
        'expected_hit_at_1': expected_hit1,
        'expected_fractional_recall_at_3': expected_fr3,
        'packed_doc_codes_total_bytes': int(packed.nbytes),
        'all_projector_frobenius_reconstruction_error_squared': n-k
    }
assert retrieval['colliding']['unique_96bit_codes'] == 128
assert retrieval['distinct']['unique_96bit_codes'] == 512
assert retrieval['colliding']['expected_hit_at_1'] == 0.25
assert retrieval['distinct']['expected_hit_at_1'] == 1.0
assert retrieval['colliding']['expected_fractional_recall_at_3'] == 0.75
assert retrieval['distinct']['expected_fractional_recall_at_3'] == 1.0
checks['same_preservation_different_retrieval'] = {
    'arms': retrieval,
    'scope': 'SYNTHETIC Z=I512, exact-match q=e_i, one gold per query, uniform tie expectation.',
    'limitation': 'Not a proposed production method; not a semantic retrieval success claim. Both maps have shared model storage not counted in document-code totals.'
}
# 3. Pure rotation fixes neither preservation budget nor sign ranking.
# Antipodal pairs imply mean zero before/after unit normalization.
q = np.array([.8,.01]); a = np.array([.8,-.01]); b = np.array([.01,.8])
docs = np.stack([a,b,-a,-b])
R = np.array([[1,-1],[1,1]], dtype=float)/math.sqrt(2)
rot = {}
for label, T in [('unrotated', np.eye(2)), ('rotated', R)]:
    X = docs @ T; qq=q @ T
    X /= np.linalg.norm(X,axis=1,keepdims=True); qq /= np.linalg.norm(qq)
    dist = np.count_nonzero((X>=0) != (qq>=0),axis=1)
    rot[label]={'distances':dist.astype(int).tolist(),
                'best_doc':int(np.argmin(dist)),
                'cosine_scores':(X@qq).tolist()}
assert rot['unrotated']['best_doc'] == 1 and rot['rotated']['best_doc'] == 0
assert np.allclose(rot['unrotated']['cosine_scores'],rot['rotated']['cosine_scores'])
checks['rotation_same_continuous_geometry_different_bits'] = rot
# Readout of numbers in the USER/COORDINATOR report; arithmetic only.
checks['reported_table_arithmetic_not_reproduced'] = {
    'perltqa_384_minus_bm25_pp': round(72.61-72.15, 2),
    'locomo_full_minus_svd96_pp': round(45.17-24.82, 2),
    'locomo_word_minus_full_pp': round(57.42-45.17, 2),
    'locomo_bm25_minus_word_pp': round(58.70-57.42, 2),
    'locomo_total_reported_gap_pp': round(58.70-24.82, 2),
    'path_fractions_not_causal_percentages': [
        (45.17-24.82)/(58.70-24.82),
        (57.42-45.17)/(58.70-24.82),
        (58.70-57.42)/(58.70-24.82)]
}
checks['numeric_representation_example_total_bytes_for_1000_docs'] = {
    '384_packed_signs': 1000*384//8,
    '384_float32_values':1000*384*4,
    '384_float64_values':1000*384*8,
    'not_included':'shared model, vocabulary, IDs, texts, per-query arrays'
}
output={'status':'PASS_ALL_ASSERTIONS',
        'tags':['LOCAL EXPLORATORY PILOT','NOT PREREGISTERED','NOT FOR CITATION','DISCLOSE-BEFORE-USE'],
        'source_commit_under_review':'c31719bf26adc6f5c046db5941247d1e60b7feeb',
        'python':platform.python_version(),'numpy':np.__version__,
        'new_empirical_LLMZIP_benchmark':False,
        'elapsed_seconds':time.perf_counter()-started,'checks':checks}
(ROOT/'MATH_RESULTS.json').write_text(json.dumps(output,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in checks.items() if k!='same_preservation_different_retrieval'},indent=2,ensure_ascii=False))
for name, v in retrieval.items(): print(name,{key:v[key] for key in ['unique_96bit_codes','all_singleton_preservation','expected_hit_at_1','expected_fractional_recall_at_3','packed_doc_codes_total_bytes']})
print(output['status'],output['elapsed_seconds'])
