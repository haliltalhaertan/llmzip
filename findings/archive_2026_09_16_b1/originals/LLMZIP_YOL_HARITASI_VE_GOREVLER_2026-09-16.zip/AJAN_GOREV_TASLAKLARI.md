# Gerçek çok-ajan ortamı için görev taslakları

STATÜ: Bu oturumda alt LLM ajanı başlatılmadı. Aşağıdaki metinler görevlendirme taslağıdır; yapılmış iş veya bağımsız denetim sayılmaz.

Ortak çerçeve: `ARASTIRMA_PLANI.md` ve mevcut 12/24/48 bayt raporunu okuyun. Yeni namespace kullanın. main, dondurulmuş görevler ve Task4F1/BEAM değiştirilmez/çalıştırılmaz. Gerçek girdiler ve kaynak SHA'ları doğrulanır. Dışlamalar, bütçe, metrik, tokenizer ve tie kuralı sonucu görmeden sabitlenir. Yeni yöntem doğruluk kapısını geçmiyorsa durulur; sonucu iyileştirmek için kapı değiştirilmez. Alt ajan sonucu otomatik üretim kararı değildir.

## Sistem uygulayıcısı

Amaç: mevcut exact192-qscale ile aynı tokenizer/formüllü BM25S'nin gerçek servis maliyetlerini eş kapsamda karşılaştırmak. Bir, on ve yüz aktif arşiv koşullarını kaynak yeterliliğiyle tanımlamak. Build/update CPU, query CPU/wall, loaded/resident/peak RSS, USS, runtime tabanı, ortak/perarchive durum, kaynak metin ve kod boyutlarını ayrı vermek. Bir arşivin runtime tabanını yüz kez toplayıp çok-arşiv RSS saymamak. Kalite/latency aynı top-k listesini üreten koddan gelmeli. Model2Vec/Potion adayını ayrı etiketle; modelin parametre sayısını byte sanma. Harici API veya ücretli model çağrısı kullanma; gerekiyorsa engeli bildir.

Teslim: plan+hash, environment, implementasyon, oracle'a başvurmayan serving kodu, tüm ham ölçümler, model/bileşen manifesti, baseline sadakat karşılaştırması.

## Temsil/kuantizasyon uygulayıcısı

Amaç: sabit encoder ailesinde 24B payload için 192x1 / 96x2 / 48x4, 48B için 384x1 / 192x2 / 96x4. Önce mevcut tek-bit reference tam tutmalı. Her boyutta float tavanı ve bütün kuantizer yanbilgisi sayılmalı. Skor hedefi açık olmalı: sadece cosine için gerekli normu maliyet dışına atma. Gerçek bit-packed veriden puanla; hazır Nxd float matrisi ile ucuz kod maliyeti raporlama. Exact versus randomized solver ayrı kontrol. Rank yetersizliği olursa soruları silme, planın sabit kuralını uygula. Shrinkage yalnız önceden tanımlanmış ayrı ablation; kuantizer ve ölçekleme aynı anda değiştirilmez.

Teslim: codebook/weights/payload dosyaları, array shapes/dtypes/bytes, perquery top-k ve metrikler, seed/fit veri kimlikleri, float-vs-code ayrımı, epsilon/zero ve nonfinite kontrolleri.

## Bağımsız denetçi

Uygulayıcının özet sayılarını okumadan kendi önkontrolünü ve metrik hesabını yazıp hash'le. Temsil tarifini ve sabit protokolü görebilir; uygulayıcının sonuçlarına göre test seçemez. Baseline, cohort, gold eşlemesi, tie sınırı, gerçek packed-boyut, yanbilgi, model paylaşımı ve profiler'a gizlice taşınan float matrisleri kontrol et. Bağımsız metrik kodunu küçük örneklerde tam sıralama/kombinasyon sayımıyla doğrula. İşlem ve dataset isimlerinden evrensel üstünlük çıkarma. Güven aralıkları archive kümelerini kullanmalı; LME ortak konuşma bağlamları riskini raporlamalı. Latency çalışırken başka worker çalıştırma.

Teslim: PASS / PASS WITH CAVEATS / FAIL ve her kapının kanıtı; yeniden üretilmeyen kontroller ayrı. Üretime alma veya branch merge yapma. Uygulayıcı ile denetçi aynı LLM/aynı kod ise bunu bağımsızlık diye etiketleme.
