"""Storage diagnostic only; does not train or run retrieval, or change any input."""
from pathlib import Path
import collections,hashlib,json,zipfile
src=Path('/mnt/data/LLMZIP_GERCEK_12_24_48_BAYT_2026-09-16.zip')
out=Path('/mnt/data/LLMZIP_YOL_HARITASI_2026-09-16')
groups=collections.defaultdict(lambda:{'archives':0,'documents':0,'text_bytes':0,'by_text':{},'archive_hashes':[]})
with zipfile.ZipFile(src) as z:
    names=sorted(n for n in z.namelist() if '/inputs/' in n and n.endswith('.json'))
    for n in names:
        data=json.loads(z.read(n)); g=groups[data['dataset']]
        g['archives']+=1
        ordered=hashlib.sha256()
        for t in data['texts']:
            b=t.encode('utf-8'); h=hashlib.sha256(b).hexdigest()
            ordered.update(len(b).to_bytes(8,'big')); ordered.update(b)
            g['documents']+=1;g['text_bytes']+=len(b)
            # SHA256 keyed and length checked; no raw text written to report.
            old=g['by_text'].get(h)
            if old is None:g['by_text'][h]=[len(b),1]
            else:
                assert old[0]==len(b)
                old[1]+=1
        g['archive_hashes'].append(ordered.hexdigest())
summary={}
for name,g in groups.items():
    uniques=g.pop('by_text'); a=g.pop('archive_hashes')
    g.update(unique_exact_texts=len(uniques),unique_text_bytes=sum(v[0] for v in uniques.values()),unique_ordered_archives=len(set(a)),most_repeated_text_count=max(v[1] for v in uniques.values()))
    g['duplicate_occurrence_fraction']=1-g['unique_exact_texts']/g['documents']
    summary[name]=g
receipt={'purpose':'Exact UTF-8 text duplication diagnostic; not new quality/RAM/CPU benchmark. No tokenization or normalization. SHA256-keyed deduplication. Does not imply fitted TF-IDF/SVD models are identical. Metadata, pointers, allocator and codebook costs excluded from text-byte totals.', 'source':str(src),'source_sha256':hashlib.file_digest(src.open('rb'),'sha256').hexdigest(),'input_json_count':len(names),'datasets':summary}
(out/'EXACT_TEXT_DUPLICATION.json').write_text(json.dumps(receipt,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(receipt,indent=2,ensure_ascii=False))
